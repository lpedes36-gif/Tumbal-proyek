"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { ArrowLeft, Eye, EyeOff, LockKeyhole, Sparkles } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function signIn(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    setNotice("");
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
      if (error) throw error;
      router.replace("/dashboard");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login gagal. Coba lagi.");
    } finally {
      setLoading(false);
    }
  }

  async function signUp() {
    setLoading(true); setError(""); setNotice("");
    try {
      const supabase = createClient();
      const { error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: { emailRedirectTo: `${window.location.origin}/auth/callback?next=/dashboard` }
      });
      if (error) throw error;
      setNotice("Pendaftaran diproses. Periksa email untuk konfirmasi akun jika konfirmasi email diaktifkan.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Pendaftaran gagal. Coba lagi.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="auth-layout">
      <section className="auth-story"><Link className="brand brand-light" href="/"><span className="brand-mark"><Sparkles size={18}/></span> tumbal<span className="brand-dot">.</span></Link><div className="auth-story-copy"><div className="eyebrow eyebrow-light"><span className="pulse"/> RUANG KERJA DIGITALMU</div><h1>Tempat ide<br/>menjadi <span>nyata.</span></h1><p>Semua yang kamu butuhkan untuk tetap fokus, terorganisir, dan bergerak maju.</p><div className="auth-quote"><div className="quote-line"/><div><strong>“Clarity creates momentum.”</strong><small>Workspace notes, vol. 01</small></div></div></div><div className="auth-story-bottom"><LockKeyhole size={15}/> Sesi aman · Data terlindungi</div></section>
      <section className="auth-form-side"><Link href="/" className="back-link"><ArrowLeft size={16}/> Kembali ke beranda</Link><div className="auth-form-wrap"><div className="auth-mobile-brand"><span className="brand-mark"><Sparkles size={18}/></span> tumbal.</div><div className="form-kicker">WORKSPACE ACCESS</div><h2>Selamat datang.</h2><p className="form-subtitle">Masuk atau buat akun untuk melanjutkan.</p>
        <form onSubmit={signIn} className="login-form">
          <label htmlFor="email">Alamat email</label><input id="email" type="email" autoComplete="email" required maxLength={254} placeholder="nama@email.com" value={email} onChange={e => setEmail(e.target.value)}/>
          <div className="password-label"><label htmlFor="password">Kata sandi</label><span>Minimal 8 karakter disarankan</span></div>
          <div className="password-wrap"><input id="password" type={showPassword ? "text" : "password"} autoComplete="current-password" required minLength={6} maxLength={128} placeholder="Masukkan kata sandi" value={password} onChange={e => setPassword(e.target.value)}/><button type="button" aria-label={showPassword ? "Sembunyikan kata sandi" : "Tampilkan kata sandi"} onClick={() => setShowPassword(!showPassword)}>{showPassword ? <EyeOff size={17}/> : <Eye size={17}/>}</button></div>
          {error && <div className="form-message form-error" role="alert">{error}</div>}{notice && <div className="form-message form-notice" role="status">{notice}</div>}
          <button className="button button-dark auth-submit" disabled={loading} type="submit">{loading ? "Memproses..." : "Masuk ke dashboard"} <span>↗</span></button>
        </form>
        <div className="or-divider"><span/> <small>ATAU</small> <span/></div>
        <button className="button button-outline auth-submit" type="button" disabled={loading || !email.trim() || password.length < 6} onClick={signUp}>Buat akun baru <span>＋</span></button>
        <p className="auth-legal">Dengan melanjutkan, kamu menyetujui penggunaan workspace sesuai kebijakan privasi dan ketentuan layanan yang berlaku.</p>
      </div><div className="auth-footer">© {new Date().getFullYear()} Tumbal Workspace <span>•</span> Dibuat dengan perhatian.</div></section>
    </main>
  );
}
