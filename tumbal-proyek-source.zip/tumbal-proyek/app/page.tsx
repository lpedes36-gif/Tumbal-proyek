import Link from "next/link";
import { ArrowUpRight, ShieldCheck, Layers3, Sparkles, LockKeyhole, ChartNoAxesCombined, CircleCheck } from "lucide-react";

const features = [
  { icon: Layers3, title: "Semua proyek, satu ruang", text: "Kelola pekerjaan dan progres tanpa kehilangan fokus." },
  { icon: ShieldCheck, title: "Keamanan sejak awal", text: "Autentikasi Supabase, proteksi rute, dan aturan akses database." },
  { icon: ChartNoAxesCombined, title: "Dashboard yang jelas", text: "Ringkasan sederhana agar hal penting selalu terlihat." }
];

export default function Home() {
  return (
    <main className="landing">
      <nav className="nav shell">
        <Link className="brand" href="/"><span className="brand-mark"><Sparkles size={18}/></span> tumbal<span className="brand-dot">.</span></Link>
        <div className="nav-links"><a href="#fitur">Fitur</a><a href="#keamanan">Keamanan</a></div>
        <Link className="button button-dark button-small" href="/login">Masuk <ArrowUpRight size={16}/></Link>
      </nav>

      <section className="hero shell">
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse"/> WORKSPACE UNTUK IDE BESAR</div>
          <h1>Kerja lebih terarah.<br/><span className="gradient-text">Hasil lebih berarti.</span></h1>
          <p className="hero-description">Ruang kerja digital yang terasa ringan, terlihat premium, dan dibangun dengan keamanan sebagai fondasi.</p>
          <div className="hero-actions"><Link className="button button-dark" href="/login">Mulai sekarang <ArrowUpRight size={18}/></Link><a className="text-link" href="#fitur">Jelajahi fitur <span>↓</span></a></div>
          <div className="social-proof"><div className="avatar-stack"><span>R</span><span>A</span><span>D</span><span>+</span></div><div><strong>Dibuat untuk fokus.</strong><small>Simple by design · Secure by default</small></div></div>
        </div>
        <div className="hero-visual" aria-label="Pratinjau dashboard">
          <div className="glow glow-one"/><div className="glow glow-two"/>
          <div className="mock-window">
            <div className="mock-top"><div className="window-dots"><i/><i/><i/></div><span>tumbal / overview</span><span className="mock-status"><span/> LIVE</span></div>
            <div className="mock-content">
              <div className="mock-greeting"><div><small>MONDAY, YOUR WORKSPACE</small><h3>Selamat datang kembali 👋</h3></div><div className="mock-user">H</div></div>
              <div className="metric-grid"><div className="metric-card"><span>Total proyek</span><strong>08</strong><small className="positive">↗ Ruang untuk bertumbuh</small></div><div className="metric-card"><span>Progres rata-rata</span><strong>72<span>%</span></strong><div className="progress"><i/></div></div></div>
              <div className="mock-section-title"><strong>Proyek terbaru</strong><span>Lihat semua ↗</span></div>
              <div className="project-row"><div className="project-icon purple">✳</div><div className="project-meta"><strong>Brand refresh</strong><small>Design system · 4 tugas</small></div><div className="project-progress"><div className="progress"><i/></div><small>84%</small></div></div>
              <div className="project-row"><div className="project-icon orange">◈</div><div className="project-meta"><strong>Website launch</strong><small>Development · 7 tugas</small></div><div className="project-progress"><div className="progress progress-orange"><i/></div><small>58%</small></div></div>
              <div className="project-row"><div className="project-icon green">⌘</div><div className="project-meta"><strong>Growth dashboard</strong><small>Analytics · 3 tugas</small></div><div className="project-progress"><div className="progress progress-green"><i/></div><small>36%</small></div></div>
            </div>
          </div>
          <div className="floating-card"><span className="floating-icon"><LockKeyhole size={17}/></span><div><strong>Security first</strong><small>Data tetap milikmu</small></div><CircleCheck size={18} className="check-icon"/></div>
        </div>
      </section>

      <section className="trust-strip"><div className="shell trust-inner"><span>DIBANGUN DENGAN</span><strong><ShieldCheck size={17}/> Security-first</strong><strong><Layers3 size={17}/> Clean workflow</strong><strong><Sparkles size={17}/> Thoughtful design</strong></div></section>

      <section className="features-section shell" id="fitur">
        <div className="section-heading"><div className="eyebrow">DIBUAT UNTUK BEKERJA LEBIH BAIK</div><h2>Fokus pada pekerjaan.<br/><span className="muted-heading">Bukan kerumitannya.</span></h2><p>Fondasi yang rapi untuk membangun, mengatur, dan mengembangkan ide.</p></div>
        <div className="feature-grid">{features.map((feature) => <article className="feature-card" key={feature.title}><div className="feature-icon"><feature.icon size={21}/></div><h3>{feature.title}</h3><p>{feature.text}</p><span className="feature-arrow">↗</span></article>)}</div>
      </section>

      <section className="security-band" id="keamanan"><div className="shell security-inner"><div className="security-icon"><ShieldCheck size={27}/></div><div><div className="eyebrow">KEAMANAN BUKAN FITUR TAMBAHAN</div><h2>Privasi dan kontrol,<br/>sejak baris pertama.</h2><p>Akses data dipisahkan per pengguna. Kunci rahasia tidak ditaruh di frontend, dan database memakai Row Level Security.</p></div><Link href="/login" className="button button-light">Masuk ke workspace <ArrowUpRight size={17}/></Link></div></section>

      <footer className="footer shell"><Link className="brand" href="/"><span className="brand-mark"><Sparkles size={16}/></span> tumbal<span className="brand-dot">.</span></Link><span>© {new Date().getFullYear()} Tumbal Workspace</span><span>Made for meaningful work.</span></footer>
    </main>
  );
}
