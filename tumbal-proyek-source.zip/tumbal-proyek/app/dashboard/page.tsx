import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { ArrowUpRight, Bell, CheckCircle2, CircleHelp, FolderKanban, LayoutDashboard, LogOut, Plus, Settings, ShieldCheck, Sparkles } from "lucide-react";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: projects } = await supabase
    .from("projects")
    .select("id, name, description, status, created_at")
    .order("created_at", { ascending: false })
    .limit(6);

  async function signOut() {
    "use server";
    const client = await createClient();
    await client.auth.signOut();
    redirect("/login");
  }

  const projectList = projects ?? [];
  const displayName = user.user_metadata?.full_name || user.email?.split("@")[0] || "Pengguna";

  return (
    <main className="dashboard-layout">
      <aside className="sidebar">
        <Link className="brand" href="/"><span className="brand-mark"><Sparkles size={17}/></span> tumbal<span className="brand-dot">.</span></Link>
        <div className="workspace-label">WORKSPACE <span>⌄</span></div>
        <nav className="side-nav"><a className="side-link active" href="#overview"><LayoutDashboard size={17}/> Overview</a><a className="side-link" href="#projects"><FolderKanban size={17}/> Proyek</a><a className="side-link" href="#security"><ShieldCheck size={17}/> Keamanan</a></nav>
        <div className="sidebar-bottom"><div className="help-card"><CircleHelp size={18}/><strong>Butuh bantuan?</strong><p>Mulai dengan panduan singkat workspace.</p><a href="#projects">Lihat panduan <ArrowUpRight size={13}/></a></div><div className="profile-row"><div className="profile-avatar">{displayName.slice(0,1).toUpperCase()}</div><div className="profile-meta"><strong>{displayName}</strong><small>{user.email}</small></div><form action={signOut}><button className="icon-button" aria-label="Keluar" title="Keluar"><LogOut size={16}/></button></form></div></div>
      </aside>
      <section className="dashboard-main" id="overview">
        <header className="dashboard-topbar"><div className="breadcrumb">Workspace <span>/</span> <strong>Overview</strong></div><div className="topbar-actions"><span className="secure-pill"><ShieldCheck size={14}/> Secure session</span><button className="icon-button" aria-label="Notifikasi"><Bell size={17}/></button><div className="profile-avatar top-avatar">{displayName.slice(0,1).toUpperCase()}</div></div></header>
        <div className="dashboard-content"><div className="dashboard-welcome"><div><div className="eyebrow">YOUR WORKSPACE AT A GLANCE</div><h1>Selamat datang, {displayName} <span>✳</span></h1><p>Ini ruangmu untuk mengubah rencana menjadi progres.</p></div><a href="#projects" className="button button-dark"><Plus size={17}/> Lihat proyek <ArrowUpRight size={16}/></a></div>
          <div className="dashboard-metrics"><article className="dash-metric"><div className="metric-top"><span>Total proyek</span><span className="metric-symbol purple">▦</span></div><strong>{projectList.length.toString().padStart(2,"0")}</strong><small>Proyek terbaru yang ditampilkan</small></article><article className="dash-metric"><div className="metric-top"><span>Status akun</span><span className="metric-symbol green"><CheckCircle2 size={17}/></span></div><strong className="metric-word">Aktif</strong><small>Akun berhasil terautentikasi</small></article><article className="dash-metric"><div className="metric-top"><span>Perlindungan</span><span className="metric-symbol blue"><ShieldCheck size={17}/></span></div><strong className="metric-word">Aktif</strong><small>RLS database perlu diaktifkan</small></article></div>
          <div className="content-columns"><section className="panel projects-panel" id="projects"><div className="panel-heading"><div><h2>Proyek terbaru</h2><p>Daftar proyek yang terhubung dengan akunmu.</p></div><span className="panel-count">{projectList.length} item</span></div>
            {projectList.length ? <div className="dashboard-project-list">{projectList.map((project, index) => <article className="dashboard-project" key={project.id}><div className={`project-icon ${["purple","orange","green"][index % 3]}`}>{["✳","◈","⌘"][index % 3]}</div><div className="project-meta"><strong>{project.name}</strong><small>{project.description || "Belum ada deskripsi"}</small></div><span className={`status-tag ${(project.status || "active").toLowerCase()}`}>{project.status || "active"}</span></article>)}</div> : <div className="empty-state"><div className="empty-icon"><FolderKanban size={24}/></div><h3>Ruangmu siap diisi.</h3><p>Belum ada proyek di database. Tambahkan data contoh melalui SQL editor Supabase atau kembangkan fitur tambah proyek berikutnya.</p></div>}
          </section><aside className="panel security-panel" id="security"><div className="security-panel-icon"><ShieldCheck size={21}/></div><div className="eyebrow">SECURITY OVERVIEW</div><h2>Akunmu, tetap terkendali.</h2><p>Autentikasi ditangani Supabase. Pastikan kebijakan Row Level Security di database telah dijalankan sebelum menyimpan data pengguna.</p><div className="security-check"><CheckCircle2 size={16}/><span>Login dengan sesi terkelola</span></div><div className="security-check"><CheckCircle2 size={16}/><span>Rute dashboard dilindungi</span></div><div className="security-check"><CheckCircle2 size={16}/><span>Contoh kebijakan RLS tersedia</span></div><Link href="/" className="security-link">Tentang Tumbal <ArrowUpRight size={15}/></Link></aside></div>
          <footer className="dashboard-footer"><span>© {new Date().getFullYear()} Tumbal Workspace</span><span><ShieldCheck size={14}/> Your workspace, your data.</span></footer>
        </div>
      </section>
    </main>
  );
}
