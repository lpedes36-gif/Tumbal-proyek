import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tumbal — Workspace",
  description: "Workspace premium untuk mengelola proyek dengan aman.",
  applicationName: "Tumbal"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
