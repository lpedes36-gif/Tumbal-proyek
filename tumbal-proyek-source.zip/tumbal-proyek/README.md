# Tumbal — Premium Workspace

Starter aplikasi web untuk mengelola proyek dengan tampilan premium, login, dashboard, dan database Supabase.

## Stack

- Next.js App Router + TypeScript
- Supabase Auth untuk login/pendaftaran
- Supabase Postgres untuk data proyek
- Row Level Security (RLS) agar pengguna hanya dapat membaca/mengubah data miliknya
- Security headers dasar di Next.js

## Persiapan lokal

**Prasyarat:** Node.js 20.9+ dan akun Supabase.

1. Ekstrak ZIP ini, lalu buka folder `tumbal-proyek` di terminal.
2. Pasang dependensi:

   ```bash
   npm install
   ```

3. Buat proyek baru di [Supabase](https://supabase.com/).
4. Di Supabase, buka **Project Settings → API** (atau Connect) dan salin Project URL serta publishable/anon key.
5. Salin `.env.example` menjadi `.env.local`, lalu isi:

   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://PROJECT-ID.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=ISI_PUBLISHABLE_ATAU_ANON_KEY
   ```

   Jangan pernah memasukkan `service_role` key ke variabel `NEXT_PUBLIC_*`, Git, atau browser.

6. Di Supabase **SQL Editor**, jalankan isi `supabase/schema.sql`. Ini membuat tabel `projects` dan kebijakan RLS.
7. Di Supabase **Authentication → URL Configuration**, set Site URL ke URL lokal saat pengembangan, biasanya `http://localhost:3000`. Tambahkan redirect URL `http://localhost:3000/auth/callback`.
8. Jalankan aplikasi:

   ```bash
   npm run dev
   ```

9. Buka `http://localhost:3000`, pilih **Masuk**, lalu buat akun dengan email dan kata sandi. Jika konfirmasi email diaktifkan, ikuti tautan yang dikirim ke email dan pastikan redirect URL sudah diizinkan.

## Buat repository GitHub

Nama repository disarankan `tumbal-proyek` (gunakan tanda hubung, bukan spasi).

### Cara lewat website GitHub

1. Masuk ke [GitHub](https://github.com/new).
2. Repository name: `tumbal-proyek`.
3. Pilih **Public**.
4. Jangan centang opsi untuk menambahkan README, `.gitignore`, atau license karena file tersebut sudah ada di proyek ini.
5. Klik **Create repository**.
6. Di terminal, dari dalam folder proyek, jalankan:

   ```bash
   git init
   git add .
   git commit -m "Initial commit: Tumbal workspace"
   git branch -M main
   git remote add origin https://github.com/USERNAME/tumbal-proyek.git
   git push -u origin main
   ```

   Ganti `USERNAME` dengan username GitHub kamu. Jika Git meminta autentikasi, ikuti proses login GitHub yang ditawarkan.

### Alternatif GitHub Desktop

1. Instal dan buka GitHub Desktop.
2. Pilih **Add → Add Existing Repository** dan pilih folder proyek.
3. Jika belum menjadi repository Git, pilih **create a repository**.
4. Commit file, lalu pilih **Publish repository** dan pastikan **Keep this code private** tidak dicentang.

## Deploy online (opsional)

- Impor repository ke [Vercel](https://vercel.com/).
- Tambahkan `NEXT_PUBLIC_SUPABASE_URL` dan `NEXT_PUBLIC_SUPABASE_ANON_KEY` pada Environment Variables.
- Tambahkan domain produksi ke Supabase Auth redirect URLs, termasuk `https://DOMAIN-KAMU/auth/callback`.
- Deploy, lalu tes login, logout, dan akses dashboard saat belum login.

## Catatan keamanan

- `.env.local` masuk `.gitignore`; jangan pernah commit file itu.
- Publishable/anon key memang dapat berada di browser, tetapi keamanan data bergantung pada kebijakan RLS yang benar.
- Jangan pernah mengekspos Supabase `service_role` key.
- Gunakan kata sandi unik, aktifkan konfirmasi email, dan atur rate limit serta proteksi CAPTCHA di Supabase Auth untuk produksi.
- Security headers pada contoh ini adalah baseline, bukan audit keamanan menyeluruh.
- Tambahkan kebijakan privasi, halaman pemulihan kata sandi, monitoring, dan pengujian sebelum aplikasi dipakai untuk data sensitif.
- Dashboard saat ini menampilkan proyek yang sudah ada. Form CRUD untuk membuat/mengedit/menghapus proyek belum dibuat.

## Struktur folder

```text
app/
  auth/callback/route.ts
  dashboard/page.tsx
  login/page.tsx
  globals.css
  layout.tsx
  page.tsx
lib/supabase/
  client.ts
  server.ts
supabase/schema.sql
middleware.ts
```
